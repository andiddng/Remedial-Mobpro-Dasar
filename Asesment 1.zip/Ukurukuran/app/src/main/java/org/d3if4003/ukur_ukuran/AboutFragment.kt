package org.d3if4003.ukur_ukuran

import androidx.fragment.app.Fragment

class AboutFragment : Fragment(R.layout.fragment_about)