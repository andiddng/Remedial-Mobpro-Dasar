package org.d3if4003.ukur_ukuran

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import org.d3if4003.ukur_ukuran.databinding.FragmentCelsiusFahrenheitBinding

class CelsiusFahrenheitFragment : Fragment() {
    private lateinit var binding: FragmentCelsiusFahrenheitBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCelsiusFahrenheitBinding.inflate(layoutInflater, container, false)
        binding.konversi.setOnClickListener { celsiusFahrenheit() }
        binding.bagikan.setOnClickListener { shareData() }
        setHasOptionsMenu(true)
        return binding.root
    }

    private fun celsiusFahrenheit() {
        val nilaiCelsius = binding.editTextNumber.text.toString()
        if (TextUtils.isEmpty(nilaiCelsius)) {
            Toast.makeText(context, R.string.salah, Toast.LENGTH_LONG).show()
            return
        }

        val celsiusFahrenheit = (nilaiCelsius.toFloat()*1.8)+32

        binding.hasilfar.text = getString(R.string.hasil, celsiusFahrenheit)
        binding.buttonGroup.visibility = View.VISIBLE
    }

    private fun shareData() {

        val message = getString(
            R.string.bagikanCelsius,
            binding.editTextNumber.text,
            binding.hasilfar.text
        )

        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain").putExtra(Intent.EXTRA_TEXT, message)
        if (shareIntent.resolveActivity(requireActivity().packageManager) != null) {
            startActivity(shareIntent)
        }
    }
}