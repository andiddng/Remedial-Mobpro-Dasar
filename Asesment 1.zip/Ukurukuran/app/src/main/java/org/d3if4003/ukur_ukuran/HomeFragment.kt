package org.d3if4003.ukur_ukuran

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import org.d3if4003.ukur_ukuran.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        binding.btCelsius.setOnClickListener { view: View ->
            view.findNavController().navigate(
                HomeFragmentDirections.actionHomeFragmentToCelsiusFahrenheitFragment()
            )
        }
        binding.btFahrenheit.setOnClickListener { view: View ->
            view.findNavController().navigate(
                HomeFragmentDirections.actionHomeFragmentToFahrenheitCelsiusFragment()
            )
        }
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_about) {
            findNavController().navigate(R.id.action_homeFragment2_to_aboutFragment)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}