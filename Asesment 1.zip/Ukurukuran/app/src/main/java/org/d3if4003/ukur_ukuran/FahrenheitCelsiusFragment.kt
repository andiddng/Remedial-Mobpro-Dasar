package org.d3if4003.ukur_ukuran

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import org.d3if4003.ukur_ukuran.databinding.FragmentFahrenheitCelciusBinding

class FahrenheitCelsiusFragment : Fragment() {
    private lateinit var binding: FragmentFahrenheitCelciusBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFahrenheitCelciusBinding.inflate(layoutInflater, container, false)
        binding.konversi.setOnClickListener { fahrenheitCelsius() }
        binding.bagikan.setOnClickListener { shareData() }
        setHasOptionsMenu(true)
        return binding.root
    }

    private fun fahrenheitCelsius() {
        val nilaiFahrenheit = binding.editTextNumber.text.toString()
        if (TextUtils.isEmpty(nilaiFahrenheit)) {
            Toast.makeText(context, R.string.salah, Toast.LENGTH_LONG).show()
            return
        }

        val fahrenheitCelsius = (nilaiFahrenheit.toFloat() - 32) * 0.5

        binding.hasilcel.text = getString(R.string.hasil, fahrenheitCelsius)
        binding.buttonGroup.visibility = View.VISIBLE
    }

    private fun shareData() {

        val message = getString(
            R.string.bagikanCelsius,
            binding.editTextNumber.text,
            binding.hasilcel.text
        )

        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain").putExtra(Intent.EXTRA_TEXT, message)
        if (shareIntent.resolveActivity(requireActivity().packageManager) != null) {
            startActivity(shareIntent)
        }
    }
}